package com.example.eggfishingauto

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 40, 36, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        layout.addView(TextView(this).apply {
            text = "🎣 Egg Fishing Auto"
            textSize = 26f
        })
        layout.addView(TextView(this).apply {
            text = "Hold to cast 좌표와 12회 터치 좌표를 화면 픽셀로 입력하세요."
            textSize = 14f
            setPadding(0, 18, 0, 18)
        })
        val castX = edit("Hold to cast X 좌표", "900")
        val castY = edit("Hold to cast Y 좌표", "1200")
        val tapX = edit("12회 터치 X 좌표", "540")
        val tapY = edit("12회 터치 Y 좌표", "1200")
        val width = edit("화면 너비(px) — 좌표 확인용", "1080")
        listOf(castX, castY, tapX, tapY, width).forEach { layout.addView(it) }

        status = TextView(this).apply {
            textSize = 14f
            setPadding(0, 20, 0, 12)
            text = "상태: 정지"
        }
        layout.addView(status)
        layout.addView(Button(this).apply {
            text = "접근성 권한 설정"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "설정 저장"
            setOnClickListener {
                prefs.edit()
                    .putInt("castX", castX.text.toString().toIntOrNull() ?: 900)
                    .putInt("castY", castY.text.toString().toIntOrNull() ?: 1200)
                    .putInt("tapX", tapX.text.toString().toIntOrNull() ?: 540)
                    .putInt("tapY", tapY.text.toString().toIntOrNull() ?: 1200)
                    .putBoolean("enabled", false).apply()
                status.text = "설정 저장됨"
            }
        })
        layout.addView(Button(this).apply {
            text = "▶ 자동 낚시 시작"
            setOnClickListener {
                saveCoords(castX, castY, tapX, tapY)
                prefs.edit().putBoolean("enabled", true).apply()
                status.text = "상태: 실행 요청됨 (게임 화면으로 이동)"
            }
        })
        layout.addView(Button(this).apply {
            text = "■ 정지"
            setOnClickListener {
                prefs.edit().putBoolean("enabled", false).apply()
                status.text = "상태: 정지"
            }
        })
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    private fun edit(label: String, value: String): EditText {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(TextView(this).apply { text = label })
        val input = EditText(this).apply {
            setText(value)
            inputType = 2
            singleLine = true
        }
        box.addView(input)
        // Keep the input discoverable by its hint.
        input.hint = label
        return input
    }

    private fun saveCoords(cx: EditText, cy: EditText, tx: EditText, ty: EditText) {
        prefs.edit()
            .putInt("castX", cx.text.toString().toIntOrNull() ?: 900)
            .putInt("castY", cy.text.toString().toIntOrNull() ?: 1200)
            .putInt("tapX", tx.text.toString().toIntOrNull() ?: 540)
            .putInt("tapY", ty.text.toString().toIntOrNull() ?: 1200)
            .apply()
    }
}
