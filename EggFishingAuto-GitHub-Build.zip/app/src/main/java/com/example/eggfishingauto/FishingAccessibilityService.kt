package com.example.eggfishingauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class FishingAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private var running = false
    private var busy = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.post(tick)
    }

    private val tick = object : Runnable {
        override fun run() {
            val enabled = prefs.getBoolean("enabled", false)
            if (!enabled) {
                running = false
                busy = false
                handler.postDelayed(this, 300)
                return
            }
            if (!running && !busy) {
                running = true
                runCycle()
            }
            handler.postDelayed(this, 300)
        }
    }

    private fun runCycle() {
        if (!prefs.getBoolean("enabled", false)) {
            running = false
            return
        }
        val x = prefs.getInt("castX", 900).toFloat()
        val y = prefs.getInt("castY", 1200).toFloat()
        busy = true
        gesture(x, y, 1500L) {
            handler.postDelayed({
                if (!prefs.getBoolean("enabled", false)) { finishCycle(); return@postDelayed }
                // Wait 5.5 seconds, then tap the configured spot 12 times.
                tapSequence(12)
            }, 5500L)
        }
    }

    private fun tapSequence(remaining: Int) {
        if (!prefs.getBoolean("enabled", false) || remaining <= 0) {
            finishCycle()
            return
        }
        val x = prefs.getInt("tapX", 540).toFloat()
        val y = prefs.getInt("tapY", 1200).toFloat()
        gesture(x, y, 45L) {
            handler.postDelayed({ tapSequence(remaining - 1) }, 65L)
        }
    }

    private fun gesture(x: Float, y: Float, duration: Long, done: () -> Unit) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        val builder = GestureDescription.Builder().addStroke(stroke)
        val dispatched = dispatchGesture(builder.build(), object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { done() }
            override fun onCancelled(gestureDescription: GestureDescription?) { done() }
        }, null)
        if (!dispatched) done()
    }

    private fun finishCycle() {
        busy = false
        running = false
        if (prefs.getBoolean("enabled", false)) {
            handler.postDelayed({ if (prefs.getBoolean("enabled", false)) runCycle() }, 500L)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {
        prefs.edit().putBoolean("enabled", false).apply()
        busy = false
        running = false
    }
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
