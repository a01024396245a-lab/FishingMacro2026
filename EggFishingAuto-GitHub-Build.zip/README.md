# Egg Fishing Auto (Android Studio project)

This is source code for an Android AccessibilityService-based tap helper. It is not a prebuilt APK.

## Build
1. Install Android Studio (current stable) on a computer.
2. Open this folder as a project.
3. Let Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on your Android phone.

## Use
1. Open Egg Fishing Auto.
2. Grant its Accessibility permission in Android Settings > Accessibility.
3. Set the screen coordinates for the cast hold and repeated tap target.
4. Save settings, return to the app, start, then switch to Roblox.
5. Stop from the app or disable the accessibility service to end it.

## Important
- Defaults are placeholders and will likely need adjustment for your phone's resolution and Roblox UI layout.
- The loop presses the cast coordinate for 1.5 seconds, waits 5.5 seconds, then taps the configured point 12 times with a short interval, and repeats.
- This does not visually detect the bite bar or confirm a catch; it follows the fixed timing you described.
- Android Accessibility permission is powerful. Enable it only for this app, and disable it when finished.
- Use only where automation is permitted by the game/platform rules.

## Build APK on GitHub (phone-friendly)
1. Create a new GitHub repository.
2. Upload the contents of this project folder, including the hidden `.github/workflows/android-build.yml` file.
3. Open the repository's Actions tab and select "Build EggFishingAuto APK".
4. Tap "Run workflow" if it has not started automatically.
5. When the run completes, open it and download the `EggFishingAuto-debug-apk` artifact.
