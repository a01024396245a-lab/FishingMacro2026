# Egg Fishing Auto (Android source)

This is an Android Studio source project, **not an APK**.

## What it does
When the Android Accessibility service is enabled, it repeats a fixed sequence:
1. Hold the configured cast coordinate for 1.5 seconds.
2. Wait 5.5 seconds.
3. Tap the configured tap coordinate 12 times.
4. Repeat.

It does **not** detect the fishing bar, catch timing, or the yellow Perfect zone. Coordinates in `FishingAccessibilityService.kt` are example values and must be adjusted to the device/game screen. Use only where permitted by the game's rules.

## Build
Open this folder in Android Studio and build the debug APK, or push it to GitHub and use the included Actions workflow. The generated APK is `app/build/outputs/apk/debug/app-debug.apk`.

## Enable
Install the APK, open it, enable `Egg Fishing Auto` in Android Accessibility settings, then return to the game. Accessibility services can control screen taps; enable only if you understand and trust the app.
