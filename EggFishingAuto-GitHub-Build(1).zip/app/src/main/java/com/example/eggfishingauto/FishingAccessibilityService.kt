package com.example.eggfishingauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class FishingAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    // Example coordinates only. They must be adjusted to the user's screen/game layout.
    private val castX = 900f
    private val castY = 1200f
    private val tapX = 540f
    private val tapY = 1200f

    override fun onServiceConnected() { super.onServiceConnected(); running = true; cycle() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { running = false; handler.removeCallbacksAndMessages(null) }
    override fun onDestroy() { running = false; handler.removeCallbacksAndMessages(null); super.onDestroy() }

    private fun cycle() {
        if (!running) return
        gesture(castX, castY, 1500L) {
            handler.postDelayed({
                if (!running) return@postDelayed
                tapRepeatedly(12) {
                    handler.postDelayed({ cycle() }, 500L)
                }
            }, 5500L)
        }
    }

    private fun tapRepeatedly(remaining: Int, done: () -> Unit) {
        if (!running) return
        if (remaining <= 0) { done(); return }
        gesture(tapX, tapY, 60L) {
            handler.postDelayed({ tapRepeatedly(remaining - 1, done) }, 70L)
        }
    }

    private fun gesture(x: Float, y: Float, duration: Long, done: () -> Unit) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { done() }
            override fun onCancelled(gestureDescription: GestureDescription?) { if (running) handler.postDelayed({ done() }, 250L) }
        }, null)
    }
}
