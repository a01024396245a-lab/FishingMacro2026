package com.example.eggfishingauto

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,32,32,32) }
        layout.addView(TextView(this).apply { text = "Egg Fishing Auto\\n\\n이 앱은 정해진 시간과 좌표로만 터치합니다. 낚시바를 자동 인식하지 않습니다."; textSize = 18f })
        layout.addView(Button(this).apply { text = "접근성 설정 열기"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        layout.addView(TextView(this).apply { text = "서비스를 켠 뒤 게임 화면에서 아래 좌표를 기기 해상도에 맞게 수정해야 합니다. 기본 좌표는 예시입니다.\\n\\n캐스팅: 900, 1200 (1.5초 누름)\\n대기: 5.5초\\n터치: 540, 1200 (12회)" })
        layout.addView(Button(this).apply { text = "사용 방법 보기"; setOnClickListener { Toast.makeText(this@MainActivity, "접근성 설정에서 Egg Fishing Auto를 켜세요.", Toast.LENGTH_LONG).show() } })
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
